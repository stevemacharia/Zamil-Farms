from django.shortcuts import render, redirect
from .forms import UserRegisterForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm  # add this
from verify_email.email_handler import send_verification_email
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from user.models import UserProfile


def register_request(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            inactive_user = send_verification_email(request, form)
            user = form.save()
            login(request, user)
            messages.success(request, f'An email verification has sent! Check your email')
            return redirect('login_prompt')
        messages.warning(request, "Unsuccessful registration. Invalid information.")
    form = UserRegisterForm()
    return render(request=request, template_name="user/register.html", context={"register_form": form})


def login_request(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"You are now logged in as {username}.")
                return redirect("profile")
            else:
                messages.warning(request, "Invalid username or password1.")
        else:
            messages.warning(request, "Invalid username or password 2.")
    form = AuthenticationForm()
    return render(request=request, template_name="user/login.html", context={"login_form": form})


def logout_request(request):
    logout(request)
    messages.info(request, "You have successfully logged out.")
    return redirect("index")


def login_prompt(request):
    return render(request, 'user/login_prompt.html')


@login_required
def profile(request):
    user = User.objects.get(id=request.user.id)
    global userinfo
    userinfo = user
    if UserProfile.objects.filter(user=userinfo):
        if request.method == 'POST':
            u_form = UserUpdateForm(request.POST, instance=request.user)
            if u_form.is_valid():
                u_form.save()
                messages.success(request, f'Your account has been updated!')
                return redirect('profile')
            else:
                messages.warning(request, f'Failed to update your details, Kindly retry again. ')
                return redirect('profile')

    return render(request, 'user/profile.html')